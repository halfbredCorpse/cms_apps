package com.example.cmsclient;

public class Api {
    // Set to URL of machine that will run Web API
    private static final String PC_URL = "192.168.137.1",
                        ROOT_URL = "http://" + PC_URL + "/CmsApi/v1/Api.php?apicall=";

    // URLs for the Web API operations
    public static final String POST_FORM_URL = ROOT_URL + "createform",
                               GET_ANNOUNCEMENTS_URL = ROOT_URL + "getannouncements";
}

package com.example.cmsclient;

import java.sql.Date;

public class Announcement {
    private Date dateSubmitted;
    private String subject, message;

    public Announcement(Date dateSubmitted, String subject, String message) {
        this.dateSubmitted = dateSubmitted;
        this.subject = subject;
        this.message = message;
    }

    public Date getDateSubmitted() {
        return dateSubmitted;
    }

    public String getSubject() {
        return subject;
    }

    public String getMessage() {
        return message;
    }
}

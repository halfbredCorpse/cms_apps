package com.example.cmsclient;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class SendNewFormActivity extends AppCompatActivity {

    private static final int CODE_POST_REQUEST = 1025;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_new_form);
    }

    public void goToMainMenu(View view) {
        startActivity(new Intent(SendNewFormActivity.this, MainActivity.class));
    }

    public void sendForm(View view){
        EditText txt_name = findViewById(R.id.txt_Name),
                 txt_idNumber = findViewById(R.id.txt_IdNumber),
                 txt_cellphoneNumber = findViewById(R.id.txt_CellphoneNumber),
                 txt_department = findViewById(R.id.txt_Department);

        String name = txt_name.getText().toString(),
               idNumber = txt_idNumber.getText().toString(),
               cellphoneNumber = txt_cellphoneNumber.getText().toString(),
               department = txt_department.getText().toString();

        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = format.format(date);

        HashMap<String, String> params = new HashMap<>();
        params.put("dateSubmitted", currentTime);
        params.put("name", name);
        params.put("idNumber", idNumber);
        params.put("cellphoneNumber", cellphoneNumber);
        params.put("department", department);

        PerformNetworkRequest request = new PerformNetworkRequest(Api.POST_FORM_URL, params, CODE_POST_REQUEST);
        request.execute();
    }

    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;

        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            try {
                JSONObject json = new JSONObject(s);
                if (!json.getBoolean("error"))
                    Toast.makeText(getApplicationContext(), json.getString("message"), Toast.LENGTH_LONG).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler handler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return handler.sendPostRequest(url, params);

            return null;
        }
    }
}

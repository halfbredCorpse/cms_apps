package com.example.cmsclient;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewAnnouncementsActivity extends AppCompatActivity {
    private static final int CODE_GET_REQUEST = 1024;

    List<Announcement> announcements;
    Announcement announcement;
    int currentAnnouncement;

    EditText txt_dateSubmitted, txt_subject, txt_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_announcements);

        announcements = new ArrayList<>();
        getAnnouncements();

        txt_dateSubmitted = findViewById(R.id.txt_DateSubmitted);
        txt_subject = findViewById(R.id.txt_Subject);
        txt_message = findViewById(R.id.txt_Message);
    }

    public void nextAnnouncement(View view) {
        if (currentAnnouncement != this.announcements.size()-1) {
            currentAnnouncement++;
            announcement = announcements.get(currentAnnouncement);

            txt_dateSubmitted.setText(announcement.getDateSubmitted().toString());
            txt_subject.setText(announcement.getSubject());
            txt_message.setText(announcement.getMessage());
        }
    }

    public void previousAnnouncement(View view) {
        if (currentAnnouncement != 0) {
            currentAnnouncement--;
            announcement = announcements.get(currentAnnouncement);

            txt_dateSubmitted.setText(announcement.getDateSubmitted().toString());
            txt_subject.setText(announcement.getSubject());
            txt_message.setText(announcement.getMessage());
        }
    }

    public void goToMainMenu(View view) {
        startActivity(new Intent(ViewAnnouncementsActivity.this, MainActivity.class));
    }

    private void getAnnouncements() {
        PerformNetworkRequest request = new PerformNetworkRequest(Api.GET_ANNOUNCEMENTS_URL, null, CODE_GET_REQUEST);
        request.execute();
    }

    private void refreshAnnouncements(JSONArray announcements) throws JSONException {
        this.announcements.clear();

        for (int i = 0; i < announcements.length(); i++) {
            JSONObject json = announcements.getJSONObject(i);

            Date sqlDate = null;

            try {
                String dateSubmitted = json.getString("dateSubmitted");
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.util.Date utilDate = format.parse(dateSubmitted);
                // Timestamp stamp = Timestamp.
                sqlDate = new Date(utilDate.getTime());
            } catch (Exception e) {
                e.printStackTrace();
            }

            this.announcements.add(new Announcement(
                    sqlDate,
                    json.getString("subject"),
                    json.getString("message")));
        }

        this.announcement = this.announcements.get(currentAnnouncement);

        txt_dateSubmitted.setText(announcement.getDateSubmitted().toString());
        txt_subject.setText(announcement.getSubject());
        txt_message.setText(announcement.getMessage());
    }

    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;
        ProgressBar progressBar = findViewById(R.id.progressBar);

        public PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);

            try {
                JSONObject json = new JSONObject(s);
                if (!json.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), json.getString("message"), Toast.LENGTH_LONG).show();
                    refreshAnnouncements(json.getJSONArray("announcements"));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler handler = new RequestHandler();

            if (requestCode == CODE_GET_REQUEST)
                return handler.sendGetRequest(url);

            return null;
        }
    }
}

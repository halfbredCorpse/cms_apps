package com.example.cmsserver;

public class Api {
    // Set to URL of machine that will run Web API
    private static final String PC_URL = "192.168.137.1";

    // URLs for the web API operations
    public static final String API_URL = "http://" + PC_URL + "/CmsApi/v1/Api.php?apicall=",
                               POST_ANNOUNCEMENT_URL = API_URL + "createannouncement",
                               GET_FORMS_URL = API_URL + "getforms";
}

package com.example.cmsserver;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewFormsActivity extends AppCompatActivity {
    private static final int CODE_GET_REQUEST = 1024;

    List<Form> forms;
    Form form;
    int currentForm;

    EditText txt_dateSubmitted, txt_name, txt_idNumber, txt_cellphoneNumber, txt_department;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_forms);

        forms = new ArrayList<>();
        getForms();

        txt_dateSubmitted = findViewById(R.id.txt_dateSubmitted);
        txt_name = findViewById(R.id.txt_Name);
        txt_idNumber = findViewById(R.id.txt_IdNumber);
        txt_cellphoneNumber = findViewById(R.id.txt_CellphoneNumber);
        txt_department = findViewById(R.id.txt_Department);
    }

    public void returnToMainMenu(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }

    public void nextForm(View view) {
        if (currentForm != forms.size()-1) {
            currentForm++;
            form = forms.get(currentForm);

            txt_dateSubmitted.setText(form.getDateSubmitted().toString());
            txt_name.setText(form.getName());
            txt_idNumber.setText(form.getIdNumber());
            txt_cellphoneNumber.setText(form.getCellphoneNumber());
            txt_department.setText(form.getDepartment());
        }
    }

    public void previousForm(View view) {
        if (currentForm != 0) {
            currentForm--;
            form = forms.get(currentForm);

            txt_dateSubmitted.setText(form.getDateSubmitted().toString());
            txt_name.setText(form.getName());
            txt_idNumber.setText(form.getIdNumber());
            txt_cellphoneNumber.setText(form.getCellphoneNumber());
            txt_department.setText(form.getDepartment());
        }
    }

    private void getForms() {
        PerformNetworkRequest request = new PerformNetworkRequest(Api.GET_FORMS_URL, null, CODE_GET_REQUEST);
        request.execute();
    }

    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;

            public PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            try {
                JSONObject json = new JSONObject(s);
                if (!json.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), json.getString("message"), Toast.LENGTH_LONG).show();
                    refreshForms(json.getJSONArray("forms"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler handler = new RequestHandler();

            if (requestCode == CODE_GET_REQUEST)
                return handler.sendGetRequest(url);

            return null;
        }
    }

    private void refreshForms(JSONArray forms) throws JSONException {
        this.forms.clear();

        for (int i = 0; i < forms.length(); i++) {
            JSONObject json = forms.getJSONObject(i);

            Date sqlDate = null;

            try {
                String dateSubmitted = json.getString("dateSubmitted");
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.util.Date utilDate = format.parse(dateSubmitted);
                sqlDate = new Date(utilDate.getTime());
            } catch (Exception e) {
                e.printStackTrace();
            }

            this.forms.add(new Form(
                    sqlDate,
                    json.getString("name"),
                    json.getString("idNumber"),
                    json.getString("cellphoneNumber"),
                    json.getString("department")));
        }

        this.form = this.forms.get(currentForm);

        txt_dateSubmitted.setText(form.getDateSubmitted().toString());
        txt_name.setText(form.getName());
        txt_idNumber.setText(form.getIdNumber());
        txt_cellphoneNumber.setText(form.getCellphoneNumber());
        txt_department.setText(form.getDepartment());
    }
}

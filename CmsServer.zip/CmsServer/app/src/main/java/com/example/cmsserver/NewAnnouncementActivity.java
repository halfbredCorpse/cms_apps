package com.example.cmsserver;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.HashMap;

public class NewAnnouncementActivity extends AppCompatActivity {
    private static final int CODE_POST_REQUEST = 1025;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_announcement);
    }

    public void returnToMainMenu (View view) {
        startActivity(new Intent(this, MainActivity.class));
    }

    public void createAnnouncement(View view) {
        EditText txt_Subject = findViewById(R.id.txt_Subject),
                txt_Message = findViewById(R.id.txt_Message);

        String subject = txt_Subject.getText().toString(),
               message = txt_Message.getText().toString();

        java.util.Date date = new java.util.Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateTime = format.format(date);

        HashMap<String, String> params = new HashMap<>();
        params.put("dateSubmitted", dateTime);
        params.put("subject", subject);
        params.put("message", message);

        PerformNetworkRequest request = new PerformNetworkRequest(Api.POST_ANNOUNCEMENT_URL, params, CODE_POST_REQUEST);
        request.execute();
    }

    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;

        public PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            try {
                JSONObject json = new JSONObject(s);
                if (!json.getBoolean("error"))
                    Toast.makeText(getApplicationContext(), json.getString("message"), Toast.LENGTH_LONG).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler handler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return handler.sendPostRequest(url, params);

            return null;
        }
    }
}

package com.example.cmsserver;

import java.sql.Date;

public class Form {
    private Date dateSubmitted;
    private String name, idNumber, cellphoneNumber, department;

    public Form(Date dateSubmitted, String name, String idNumber, String cellphoneNumber, String department) {
        this.dateSubmitted = dateSubmitted;
        this.name = name;
        this.idNumber = idNumber;
        this.cellphoneNumber =  cellphoneNumber;
        this.department = department;
    }

    public Date getDateSubmitted() {
        return dateSubmitted;
    }

    public String getName() {
        return name;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public String getCellphoneNumber() {
        return cellphoneNumber;
    }

    public String getDepartment() {
        return department;
    }
}
